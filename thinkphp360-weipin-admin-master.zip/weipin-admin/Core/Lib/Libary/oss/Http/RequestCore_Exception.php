<?php


class RequestCore_Exception extends \Exception
{

}