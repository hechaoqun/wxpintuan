<?php
return array (
    'SHOW_PAGE_TRACE'      => true,	 // 显示TRACE页面
);
?>