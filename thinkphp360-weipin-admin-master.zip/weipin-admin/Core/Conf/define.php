<?php
define('THINK_PATH', './Core/ThinkPHP/');
define('RUNTIME_PATH','./Temp/');
define('TMPL_PATH','./Template/');
define('APP_PATH', './Core/');
define('APP_NAME', 'cms');