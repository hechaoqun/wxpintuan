<?php
return array (
  'default_theme' => 'default',
  'SHOW_PAGE_TRACE' => false,
);
?>